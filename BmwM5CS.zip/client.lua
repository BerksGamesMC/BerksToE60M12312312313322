function replaceModel()
    txd = engineLoadTXD('tahoma.txd', 566)
    engineImportTXD(txd, 566)
    dff = engineLoadDFF('tahoma.dff', 566)
    engineReplaceModel(dff, 566)
    setVehicleModelWheelSize(566, "all_wheels", 0.77)
end
addEventHandler('onClientResourceStart', getResourceRootElement(getThisResource()), replaceModel)
--addCommandHandler('reloadcar', replaceModel)