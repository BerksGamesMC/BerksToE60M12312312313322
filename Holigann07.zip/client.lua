function replaceModel()
    txd = engineLoadTXD('banshee.txd', 429)
    engineImportTXD(txd, 429)
    dff = engineLoadDFF('banshee.dff', 429)
    engineReplaceModel(dff, 429)
    setVehicleModelWheelSize(429, "all_wheels", 0.77)
end
addEventHandler('onClientResourceStart', getResourceRootElement(getThisResource()), replaceModel)
--addCommandHandler('reloadcar', replaceModel)