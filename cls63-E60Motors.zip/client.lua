function replaceModel()
    txd = engineLoadTXD('sultan.txd', 560)
    engineImportTXD(txd, 560)
    dff = engineLoadDFF('sultan.dff', 560)
    engineReplaceModel(dff, 560)
    setVehicleModelWheelSize(560, "all_wheels", 0.77)
end
addEventHandler('onClientResourceStart', getResourceRootElement(getThisResource()), replaceModel)
--addCommandHandler('reloadcar', replaceModel)