function replaceModel()
    txd = engineLoadTXD('Cheetah.txd', 415)
    engineImportTXD(txd, 415)
    dff = engineLoadDFF('Cheetah.dff', 415)
    engineReplaceModel(dff, 415)
    setVehicleModelWheelSize(415, "all_wheels", 0.77)
end
addEventHandler('onClientResourceStart', getResourceRootElement(getThisResource()), replaceModel)
--addCommandHandler('reloadcar', replaceModel)