function replaceModel()
    txd = engineLoadTXD('Sabre.txd', 475)
    engineImportTXD(txd, 475)
    dff = engineLoadDFF('Sabre.dff', 475)
    engineReplaceModel(dff, 475)
    setVehicleModelWheelSize(475, "all_wheels", 0.77)
end
addEventHandler('onClientResourceStart', getResourceRootElement(getThisResource()), replaceModel)
--addCommandHandler('reloadcar', replaceModel)